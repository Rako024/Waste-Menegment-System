package com.whosein.wastemanagement;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    EditText password, email;
    UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        email = findViewById(R.id.emailText);
        password = findViewById(R.id.usernameText);

        dbHelper = new UserDatabaseHelper(this);
    }

    public void submit(View view){
        try {
            String password1 = password.getText().toString().trim();
            String email1 = email.getText().toString().trim();

            if(email1.isEmpty() || password1.isEmpty()){
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_LONG).show();
            } else {
                boolean isValidUser = dbHelper.checkUser(email1, password1);

                if (isValidUser) {
                    // User credentials are valid
                    Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    public void register(View view){
        Intent intent = new Intent(MainActivity3.this, MainActivity4.class);
        startActivity(intent);
    }

}
