package com.whosein.wastemanagement;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

public class MainActivity6 extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap myMap;
    private EditText timeInput;
    private Button addMarkerButton;
    private Button deleteMarkerButton;
    private Button editMarkerButton;
    private Marker lastClickedMarker;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        timeInput = findViewById(R.id.time_input);
        addMarkerButton = findViewById(R.id.add_marker_button);
        deleteMarkerButton = findViewById(R.id.delete_marker_button);
        editMarkerButton = findViewById(R.id.edit_marker_button);

        addMarkerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addMarkerWithCustomTime();
            }
        });

        deleteMarkerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteSelectedMarker();
            }
        });

        editMarkerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editSelectedMarkerTime();
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        myMap = googleMap;
        LatLng baku = new LatLng(40.4093, 49.8671);
        float zoomLevel = 12.0f;
        myMap.addMarker(new MarkerOptions().position(baku).title("Baku"));
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(baku, zoomLevel));

        myMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                lastClickedMarker = marker;
                return false;
            }
        });

        loadMarkersFromDatabase();
    }

    private void addMarkerWithCustomTime() {
        if (myMap != null) {
            String inputTime = timeInput.getText().toString().trim();
            LatLng markerPosition = myMap.getCameraPosition().target;

            if (!inputTime.isEmpty() && isValidTimeFormat(inputTime)) {
                Marker marker = myMap.addMarker(new MarkerOptions()
                        .position(markerPosition)
                        .title(inputTime));

                if (marker != null) {
                    saveMarkerToDatabase(markerPosition.latitude, markerPosition.longitude, inputTime);
                }
            } else {
                Toast.makeText(this, "Invalid time format", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveMarkerToDatabase(double latitude, double longitude, String time) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_LATITUDE, latitude);
        values.put(DatabaseHelper.COLUMN_LONGITUDE, longitude);
        values.put(DatabaseHelper.COLUMN_TIME, time);

        long insertedRow = database.insert(DatabaseHelper.TABLE_MARKERS, null, values);
        if (insertedRow != -1) {
            Toast.makeText(this, "Marker added to database", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to add marker to database", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadMarkersFromDatabase() {
        Cursor cursor = database.query(DatabaseHelper.TABLE_MARKERS,
                null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") double latitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COLUMN_LATITUDE));
                @SuppressLint("Range") double longitude = cursor.getDouble(cursor.getColumnIndex(DatabaseHelper.COLUMN_LONGITUDE));
                @SuppressLint("Range") String time = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TIME));

                LatLng position = new LatLng(latitude, longitude);
                myMap.addMarker(new MarkerOptions().position(position).title(time));
            } while (cursor.moveToNext());

            cursor.close();
        }
    }

    private boolean isValidTimeFormat(String time) {
        return time.matches("([01]?[0-9]|2[0-3]):[0-5][0-9]");
    }

    private void deleteSelectedMarker() {
        if (lastClickedMarker != null) {
            lastClickedMarker.remove();
            deleteMarkerFromDatabase(lastClickedMarker);
            lastClickedMarker = null;
        }
    }

    private void deleteMarkerFromDatabase(Marker marker) {
        String markerTitle = marker.getTitle();
        if (markerTitle != null) {
            int deletedRows = database.delete(DatabaseHelper.TABLE_MARKERS,
                    DatabaseHelper.COLUMN_TIME + "=?", new String[]{markerTitle});
            if (deletedRows > 0) {
                Toast.makeText(this, "Marker deleted from database", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to delete marker from database", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void editSelectedMarkerTime() {
        if (lastClickedMarker != null) {
            String inputTime = timeInput.getText().toString().trim();

            if (!inputTime.isEmpty() && isValidTimeFormat(inputTime)) {
                lastClickedMarker.setTitle(inputTime);
                LatLng markerPosition = lastClickedMarker.getPosition();
                updateMarkerTimeInDatabase(markerPosition, inputTime);
            } else {
                Toast.makeText(this, "Invalid time format", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void updateMarkerTimeInDatabase(LatLng markerPosition, String newTime) {
        double latitude = markerPosition.latitude;
        double longitude = markerPosition.longitude;

        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TIME, newTime);

        int updatedRows = database.update(DatabaseHelper.TABLE_MARKERS, values,
                DatabaseHelper.COLUMN_LATITUDE + "=? AND " + DatabaseHelper.COLUMN_LONGITUDE + "=?",
                new String[]{String.valueOf(latitude), String.valueOf(longitude)});

        if (updatedRows > 0) {
            Toast.makeText(this, "Marker time updated in database", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to update marker time in database", Toast.LENGTH_SHORT).show();
        }
    }

    public void profile(View view) {
        Intent intent = new Intent(MainActivity6.this, MainActivity5.class);
        startActivity(intent);
    }
}
