package com.whosein.wastemanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.whosein.wastemanagement.UserDatabaseHelper;

public class MainActivity7 extends AppCompatActivity {

    EditText newUsernameEditText, newEmailEditText, newPasswordEditText;
    UserDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        newUsernameEditText = findViewById(R.id.newUsername);
        newEmailEditText = findViewById(R.id.newEmail);
        newPasswordEditText = findViewById(R.id.newPassword);

        dbHelper = new UserDatabaseHelper(this);
    }

    public void updateProfile(View view) {
        String newUsername = newUsernameEditText.getText().toString().trim();
        String newEmail = newEmailEditText.getText().toString().trim();
        String newPassword = newPasswordEditText.getText().toString().trim();

        // Check which field to update and perform the update
        if (!newUsername.isEmpty()) {
            // Update username
            // TODO: Update database with the new username
            Toast.makeText(this, "Username updated", Toast.LENGTH_SHORT).show();
        } else if (!newEmail.isEmpty()) {
            // Update email
            // TODO: Update database with the new email
            Toast.makeText(this, "Email updated", Toast.LENGTH_SHORT).show();
        } else if (!newPassword.isEmpty()) {
            // Update password
            // TODO: Update database with the new password
            Toast.makeText(this, "Password updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Please fill in at least one field", Toast.LENGTH_SHORT).show();
        }
    }

    public void goBack(View view) {
        Intent intent = new Intent(MainActivity7.this, MainActivity2.class);
        startActivity(intent);
    }
}
